package com.azure.servicebus.config;

import java.util.Hashtable;

import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.azure.servicebus.listener.SubscriptionListener;

@Configuration
public class ServiceBusConfiguration {
	
	@Value("${amqpsUrl}")
	String amqpsUrl;
	@Value("${subscriptionUrl}")
	String subscriptionUrl;
	@Value("${jndiUrl}")
	String jndiUrl;
	@Value("${sasPolicy}")
	String sasPolicy;
	@Value("${sasKey}")
	String sasKey;
	
	@Autowired
	SubscriptionListener listener;

	@Bean
	public Connection createConnection() throws NamingException, JMSException {
		Connection connection = null;
		Hashtable<String, String> env = new Hashtable<>();
		env.put("connectionfactory.SBCF", this.amqpsUrl);
		env.put("topic.TOPIC",this.subscriptionUrl);
		env.put(Context.INITIAL_CONTEXT_FACTORY, this.jndiUrl);
		Context context = new InitialContext(env);
		ConnectionFactory connectionFactory = (ConnectionFactory)context.lookup("SBCF");
		Destination topicSubscription = (Destination)context.lookup("TOPIC");
		connection = connectionFactory.createConnection(this.sasPolicy, this.sasKey);
		Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
		MessageConsumer reciever = session.createConsumer(topicSubscription);
		reciever.setMessageListener(listener);
		connection.start();
		return connection;
	}


}

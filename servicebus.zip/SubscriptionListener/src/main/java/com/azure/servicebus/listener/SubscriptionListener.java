package com.azure.servicebus.listener;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;

import org.springframework.context.annotation.Configuration;

@Configuration
public class SubscriptionListener implements MessageListener{

	@Override
	public void onMessage(Message message) {
		try {
			System.out.println("RecievedMessage :: "+message.getStringProperty("routingKey"));
		} catch (JMSException e) {
			e.printStackTrace();
		}
		
	}

}

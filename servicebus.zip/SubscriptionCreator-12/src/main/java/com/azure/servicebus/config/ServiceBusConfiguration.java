package com.azure.servicebus.config;

import java.util.Hashtable;

import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.jms.Topic;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ServiceBusConfiguration {
	
	@Value("${amqpsUrl}")
	String amqpsUrl;
	@Value("${subscriptionUrl}")
	String subscriptionUrl;
	@Value("${jndiUrl}")
	String jndiUrl;
	@Value("${sasPolicy}")
	String sasPolicy;
	@Value("${sasKey}")
	String sasKey;

	@Bean
	public Connection createConnection() throws NamingException, JMSException {
		Connection connection = null;
		Hashtable<String, String> env = new Hashtable<>();
		env.put("connectionfactory.SBCF", this.amqpsUrl);
		env.put("topic.TOPIC",this.subscriptionUrl);
		env.put("queue.QUEUE",this.subscriptionUrl);
		env.put(Context.INITIAL_CONTEXT_FACTORY, this.jndiUrl);
		Context context = new InitialContext(env);
		ConnectionFactory connectionFactory = (ConnectionFactory)context.lookup("SBCF");
		Destination topicSubscription = (Destination)context.lookup("QUEUE");
		connection = connectionFactory.createConnection(this.sasPolicy, this.sasKey);
		Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
		MessageProducer sender = session.createProducer(topicSubscription);
		Message message = session.createMessage();
		message.setStringProperty("routingKey", "router1");
		sender.send(message);
		return connection;
	}
}
